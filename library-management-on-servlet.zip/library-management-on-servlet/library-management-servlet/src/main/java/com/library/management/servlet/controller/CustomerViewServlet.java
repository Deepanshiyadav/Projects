package com.library.management.servlet.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.library.management.servlet.dao.CustomerDao;
import com.library.management.servlet.domain.CustomerDomain;
@WebServlet("/viewcustomer")
public class CustomerViewServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();

		out.println("<a href ='index.jsp'>Home</a>");
		out.println("<h2>Customer Details</h2>");

		ArrayList<CustomerDomain> list = CustomerDao.getAllDetails();

		out.print("<table>" + "<tr>" + "<td>Id</td>" + "<td><pre>	</pre></td>" + "<td>Name</td>"
				+ "<td><pre>	</pre></td>" + "<td>Address</td>" + "<td><pre>	</pre></td>" + "<td>Contact</td>"
				+ "<td><pre>	</pre></td>" + "</tr>");

		for (CustomerDomain a : list) {
			out.println("<tr>" + "<td>" + a.getId() + "</td>" + "<td><pre>	</pre></td>" + "<td>" + a.getName()
					+ "</td>" + "<td><pre>	</pre></td>" + "<td>" + a.getAddress() + "</td>" + "<td><pre>	</pre></td>"
					+ "<td>" + a.getContact() + "</td>" + "</tr>");
		}
		
		out.println("</table>");
		out.close();
	}
}