package com.library.management.servlet.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.library.management.servlet.dao.StatusDao;
import com.library.management.servlet.domain.StatusDomain;
@WebServlet("/status")
public class StatusServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();

		out.println("<a href ='index.jsp'>Home</a>");
		out.println("<h2>Customer Details</h2>");

		ArrayList<StatusDomain> list = StatusDao.status();

		out.print("<table>" + "<tr>" + "<td>BookId</td>" + "<td><pre>	</pre></td>" + "<td>CutomerId</td>"
				+ "<td><pre>	</pre></td>" + "<td>IssueDate</td>" + "<td><pre>	</pre></td>" + "<td>ReturnDate</td>"
				+ "<td><pre>	</pre></td>" + "<td>Status</td>" + "<td><pre>	</pre></td>" + "</tr>");

		for (StatusDomain e : list) {
			out.println("<tr>" + "<td>" + e.getBid() + "</td>" + "<td><pre>	</pre></td>" + "<td>" + e.getCid() + "</td>"
					+ "<td><pre>	</pre></td>" + "<td>" + e.getIssueDate() + "</td>" + "<td><pre>	</pre></td>"
					+ "<td>" + e.getReturnDate() + "</td>" + "<td><pre>	</pre></td>" + "<td>" + e.isStatus() + "</td>"
					+ "</tr>");
		}
		out.println("</table>");
		out.close();
	}

}
