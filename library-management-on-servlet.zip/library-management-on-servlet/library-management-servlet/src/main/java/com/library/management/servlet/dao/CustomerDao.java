package com.library.management.servlet.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.library.management.servlet.domain.CustomerDomain;
import com.library.management.servlet.util.JdbcConnection;

public class CustomerDao {

	public static int save(CustomerDomain a) {
		int status = 0;

		try {
			JdbcConnection c = new JdbcConnection();
			Connection con = c.connetP();
			String q = "insert into customer(cid,cname,ccontact,caddress) values(?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(q);
			ps.setInt(1, a.getId());
			ps.setString(2, a.getName());
			ps.setString(3, a.getContact());
			ps.setString(4, a.getAddress());
			status = ps.executeUpdate();
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return status;
	}

	public static ArrayList<CustomerDomain> getCustomerDetails(int cid) {
		ArrayList<CustomerDomain> list = new ArrayList<CustomerDomain>();
		CustomerDomain u = new CustomerDomain();
		try {
			JdbcConnection c = new JdbcConnection();
			Connection con = c.connetP();
			String q = "select * from customer where cid = ?";
			PreparedStatement ps = con.prepareStatement(q);
			ps.setInt(1, cid);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				u.setId(rs.getInt(1));
				u.setName(rs.getString(2));
				u.setAddress(rs.getString(3));
				u.setContact(rs.getString(4));
				list.add(u);
			} 
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return list;
	}

	public static ArrayList<CustomerDomain> getAllDetails() {
		ArrayList<CustomerDomain> list = new ArrayList<CustomerDomain>();
		CustomerDomain a = null;
		try (Connection con = new JdbcConnection().connetP(); Statement stm = con.createStatement();) {
			String q = "select * from customer";
			ResultSet rs = stm.executeQuery(q);
			while (rs.next()) {
				a = new CustomerDomain();
				a.setId(rs.getInt(1));
				a.setName(rs.getString(2));
				a.setContact(rs.getString(3));
				a.setAddress(rs.getString(4));
				list.add(a);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return list;
	}

	public static int remove(int id) {
		int status = 0;
		try {
			JdbcConnection c = new JdbcConnection();
			Connection con = c.connetP();
			String q = "delete from customer where cid = ?";
			PreparedStatement ps = con.prepareStatement(q);
			ps.setInt(1, id);
			status = ps.executeUpdate();
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return status;
	}
}