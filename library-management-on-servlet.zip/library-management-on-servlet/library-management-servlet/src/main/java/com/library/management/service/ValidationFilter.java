package com.library.management.service;

import java.io.IOException;
import java.io.PrintWriter;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.postgresql.replication.fluent.ChainedCommonCreateSlotBuilder;
@WebFilter("/addcustomer")
public class ValidationFilter extends HttpFilter {
	
	Logger logger = LoggerFactory.getLogger(ValidationFilter.class);
	
	@Override
	protected void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		
		PrintWriter out = response.getWriter();
		
		String name = request.getParameter("name");
		String contact = request.getParameter("contact");
		String address = request.getParameter("address");
		
		if(Validations.isValidCustomerName(name) && Validations.isValidContact(contact)&& Validations.isValidAddress(address) ) {
			chain.doFilter(request, response);
		}else {
			logger.debug("request path:{}", ((HttpServletRequest)request).getContextPath());
		}
		out.print("Please, Enter Valid Input");
		logger.error("logger is called");
	}

	@Override
	public void destroy() {
		logger.error("Logger is destroyed");
	}

}
