package com.library.management.servlet.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.library.management.servlet.dao.CustomerDao;
import com.library.management.servlet.domain.CustomerDomain;

@WebServlet("/customerinfo")
public class CustomerInfoServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		out.print("<h1>Customer Details</h1>");

		String id = req.getParameter("id");
		int cid = Integer.parseInt(id);
		ArrayList<CustomerDomain> list = CustomerDao.getCustomerDetails(cid);

		for (CustomerDomain a : list) {
			if (cid == a.getId()) {
				out.println("<p>Customer Id  :- " + a.getId() + "</p>" + "<p>Customer Name  :- " + a.getName() + "</p>"
						+ "<p>Customer Contact  :- " + a.getAddress() + "</p>" + "<p>Customer Address  :- "
						+ a.getContact() + "</p>");
				out.print("<a href ='index.jsp'>Home</a>");
			}break;
		}
		out.print("User Not Found <br/>");
		out.print("<a href ='index.jsp'>Home</a>");
	}
}