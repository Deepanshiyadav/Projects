package com.library.management.servlet.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.library.management.servlet.dao.BookDao;
import com.library.management.servlet.domain.BookDomain;
@WebServlet("/bookview")
public class BookDetailsServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		
		out.println("<a href ='index.jsp'>Home</a>");
		out.println("<h2>Customer Details</h2>");

		ArrayList<BookDomain> list = BookDao.getAllDetails();

		out.print("<table>" + "<tr>" + "<td>Id</td>" + "<td><pre>	</pre></td>" + "<td>Name</td>"
				+ "<td><pre>	</pre></td>" + "<td>Author</td>" + "<td><pre>	</pre></td>" + "<td>Category</td>"
				+ "<td><pre>	</pre></td>" +"<td>Price</td>" + "<td><pre>	</pre></td>" + "</tr>");

		for (BookDomain e : list) {
			out.println("<tr>" + "<td>" + e.getId() + "</td>" + "<td><pre>	</pre></td>" + "<td>" + e.getName()
					+ "</td>" + "<td><pre>	</pre></td>" + "<td>" + e.getAuthor() + "</td>" + "<td><pre>	</pre></td>"
					+ "<td>" + e.getCategory() + "</td>" + "<td><pre>	</pre></td>"
					+ "<td>" + e.getPrice() + "</td>"+"</tr>");
		}
		out.println("</table>");
		out.close();
	}
}