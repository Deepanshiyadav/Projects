package com.library.management.servlet.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.library.management.servlet.dao.StatusDao;
@WebServlet("/return")
public class ReturnBookServlet extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		String id = req.getParameter("id");
		int bid = Integer.parseInt(id);
		int status = StatusDao.retrn(bid);
		if(status>0) {
			out.print("<p>Status Update Successfully</p>");
			req.getRequestDispatcher("index.jsp").include(req, resp);
		}else {
			out.print("Sorry! unable to Update Status....Try Again...");
			req.getRequestDispatcher("index.jsp").include(req, resp);
		}
		
	}
	
}
