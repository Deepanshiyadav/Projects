package com.library.management.servlet.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.library.management.servlet.dao.StatusDao;
import com.library.management.servlet.domain.StatusDomain;

@WebServlet("/issue")
public class IssueBookServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		SimpleDateFormat d = new SimpleDateFormat("yyyy/mm/dd");
		int bid = Integer.parseInt(req.getParameter("bid"));
		int cid = Integer.parseInt(req.getParameter("cid"));
		
		String date=req.getParameter("idate");
		
		java.util.Date issueDate = null;
		java.util.Date returnDate = null;
		try {
			issueDate = d.parse(req.getParameter("idate"));
			returnDate = d.parse(req.getParameter("rdate"));
			System.out.println(date + "" + returnDate);

		} catch (ParseException e) {
			e.printStackTrace();
		}
		java.sql.Date date1 = new java.sql.Date(issueDate.getTime());
		java.sql.Date date2 = new java.sql.Date(returnDate.getTime());
		
		
		String status = req.getParameter("issue");

		StatusDomain a = new StatusDomain();
		a.setBid(bid);
		a.setCid(cid);
		a.setIssueDate(date1);
		a.setReturnDate(date2);
		a.setStatus(status);

		int statu = StatusDao.issueBook(a);
		if (statu > 0) {
			out.print("<p>Book Issue Successfully</p>");
			req.getRequestDispatcher("index.jsp").include(req, resp);
		} else {
			out.println("Sorry! unable to issue Book....Try Again....");
		}
		out.close();
	}

}
