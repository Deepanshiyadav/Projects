package com.library.management.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validations {

	public static boolean isValidCustomerName(String name) {
		String regex ="^[A-Za-z]+$";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(name);
		if (m.matches()) {
			return true;
		}
		return false;
	}
	
	public static boolean isValidAddress(String address) {
		String regex = "^[A-Za-z0-9]+&";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(address);
		if(m.matches()) {
			return true;
		}
		return false;
	}
	
	public static boolean isValidContact(String contact) {
		String regex = "(0/+91)?[7-9][0-9] {9}+$";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(contact);
		if(m.matches()) {
			return true;
		}
		return false;
	}
	
}
