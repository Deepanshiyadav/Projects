package com.library.management.servlet.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.library.management.servlet.domain.StatusDomain;
import com.library.management.servlet.util.JdbcConnection;

public class StatusDao {

	public static int issueBook(StatusDomain a) {
		int status = 0;
		try {
			JdbcConnection c = new JdbcConnection();
			Connection con = c.connetP();
			String q = "insert into book_status(bookid,customerid, issuedate, returndate, status) values(?,?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(q);
			ps.setInt(1, a.getBid());
			ps.setInt(2,a.getCid());
			ps.setDate(3, (Date) a.getIssueDate());
			ps.setDate(4,(Date)a.getReturnDate());
			ps.setString(5,a.isStatus());
			status = ps.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e);
		}
		return status;
	}

	public static int retrn(int bid) {
		int status =0;
		try {
			JdbcConnection c = new JdbcConnection();
			Connection con = c.connetP();
			String q="update book_status set status='ReturnBook' where bookid= ?";
			PreparedStatement ps = con.prepareStatement(q);
			ps.setInt(1,bid);
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return status;
	}

	public static ArrayList<StatusDomain> status() {
     ArrayList<StatusDomain> list = new ArrayList<StatusDomain>();
		try {
		JdbcConnection c = new JdbcConnection();
		Connection con = c.connetP();
		String q = "select * from book_status";
		PreparedStatement ps = con.prepareStatement(q);
		ResultSet rs =ps.executeQuery();
		while(rs.next()) {
			StatusDomain a= new StatusDomain();
			a.setBid(rs.getInt(1));
			a.setCid(rs.getInt(2));
			a.setIssueDate(rs.getDate(3));
			a.setReturnDate(rs.getDate(4));
			a.setStatus(rs.getString(5));
			list.add(a);
		}
		con.close();
	} catch (Exception e) {
		System.out.println(e);
	}
	return list;
	}
}