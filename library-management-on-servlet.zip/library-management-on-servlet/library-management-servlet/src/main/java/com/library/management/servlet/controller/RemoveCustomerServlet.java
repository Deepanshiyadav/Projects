package com.library.management.servlet.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.library.management.servlet.dao.CustomerDao;

@WebServlet("/remove")
public class RemoveCustomerServlet  extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
      
		PrintWriter out = resp.getWriter();
		
		String id = req.getParameter("id");
		int cid = Integer.parseInt(id);		
		int status = CustomerDao.remove(cid);
		if(status>0) {
			out.print("<p>Customer Remove Successfully</p>");
			req.getRequestDispatcher("index.jsp").include(req, resp);
		}else {
			out.println("Sorry! unable to Remove Customer....Try Again....");
			req.getRequestDispatcher("index.jsp").include(req, resp);
		}
	}
}
