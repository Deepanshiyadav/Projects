package com.library.management.servlet.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.library.management.servlet.dao.CustomerDao;
import com.library.management.servlet.domain.CustomerDomain;
@WebServlet("/addcustomer")
public class AddCustomerServlet extends HttpServlet{
	
	private Logger logger = LoggerFactory.getLogger(getClass());

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		
		int id = Integer.parseInt(req.getParameter("id"));
		String name =req.getParameter("name");
		String contact = req.getParameter("contact");
		String address = req.getParameter("address");
		
		CustomerDomain a = new CustomerDomain();
		a.setId(id);
		a.setName(name);
		a.setContact(contact);
		a.setAddress(address);
		
		
		int status = CustomerDao.save(a);
		if(status>0) {
			out.print("<p>Customer Add Successfully</p>");
			req.getRequestDispatcher("index.jsp").include(req, resp);
		}else {
			out.println("Sorry! unable to Add Customer....Try Again....");
		}
		out.close();
	}
}
