package com.library.management.servlet.util;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;


public class JdbcConnection {
	
	public Connection connetP() {

		Connection con = null;

		try {FileInputStream file = new FileInputStream ("D:/library-management-on-servlet/library-management-servlet/src/main/java/com/library/management/servlet/util/JdbcConnection.properties");
		Properties prop = new Properties();
		prop.load(file);
		Class.forName(prop.getProperty("driver"));
			con = DriverManager.getConnection(prop.getProperty("URL"), prop.getProperty("user"), prop.getProperty("password"));
			 System.out.println("Connection to PostgreSQL is successfully...");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return con;
	}
}
