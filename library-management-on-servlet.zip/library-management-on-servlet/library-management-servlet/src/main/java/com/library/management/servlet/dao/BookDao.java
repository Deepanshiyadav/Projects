package com.library.management.servlet.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;


import com.library.management.servlet.domain.BookDomain;
import com.library.management.servlet.util.JdbcConnection;

public class BookDao {

	public static int save(BookDomain a) {
		int status = 0;

		try {
			JdbcConnection c = new JdbcConnection();
			Connection con = c.connetP();
			String q = "insert into book(bid,bname,bauthor,bcategory,bprice) values(?,?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(q);
			ps.setInt(1, a.getId());
			ps.setString(2, a.getName());
			ps.setString(3, a.getAuthor());
			ps.setString(4, a.getCategory());
			ps.setFloat(5, a.getPrice());
			status = ps.executeUpdate();
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return status;
	}
	
	public static ArrayList<BookDomain> getAllDetails() {
		ArrayList<BookDomain> list = new ArrayList<BookDomain>();
		try {
			JdbcConnection c = new JdbcConnection();
			Connection con = c.connetP();
			String q = "select * from book";
			PreparedStatement ps = con.prepareStatement(q);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				BookDomain a = new BookDomain();
				a.setId(rs.getInt(1));
				a.setName(rs.getString(2));
				a.setAuthor(rs.getString(3));
				a.setCategory(rs.getString(4));
				a.setPrice(rs.getFloat(5));
				list.add(a);
			}
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return list;
	}
	
	public static int remove(int id) {
		int status = 0;
		try {
			JdbcConnection c = new JdbcConnection();
			Connection con = c.connetP();
			String q = "delete from Book where bid = ?";
			PreparedStatement ps = con.prepareStatement(q);
			ps.setInt(1, id);
			status = ps.executeUpdate();
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return status;
	}	
}