package com.library.management.servlet.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.library.management.servlet.dao.BookDao;
import com.library.management.servlet.domain.BookDomain;

@WebServlet("/addbook")
public class AddBookServlet extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		
		int id = Integer.parseInt(req.getParameter("id"));
		String name =req.getParameter("name");
		String author = req.getParameter("author");
		String category = req.getParameter("category");
		Float price = Float.parseFloat((req.getParameter("price")));
		
		BookDomain a = new BookDomain();
		a.setId(id);
		a.setName(name);
		a.setAuthor(author);
		a.setCategory(category);
		a.setPrice(price);
		
		int status = BookDao.save(a);
		if(status>0) {
			out.print("<p>Book Add Successfully</p>");
			req.getRequestDispatcher("index.jsp").include(req, resp);
		}else {
			out.println("Sorry! unable to Add Book....Try Again....");
		}
		out.close();
	}
}
